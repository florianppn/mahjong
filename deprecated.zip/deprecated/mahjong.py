############################################################################
#  DM MAHJONG Solitaire                                                    #
############################################################################

#importation des bibiliothèques nécessaires au jeu
from tkinter import *
from random import *
from copy import *
from pickle import *
from mesGrilles import *

dessin=Tk()
dessin.title("Mahjong")

# Les variables globales
cx=64 # dimension d'une case en largeur si on utilise les images sinon au choix
cy=84 # dimension d'une case en hauteur si on utilise les images sinon au choix
x0,y0=55,40 # coordonnées du point en haut à gauche
click1=() # le click 1
click2=() # le click 2
grille=[] # la grille
copieGrille=[] # une copie de la grille d'origine, si on veut rejouer avec
nbLignes=8 # le nombre de lignes pour le cadrillage
nbColonnes=8 # le nombre de colonnes pour le cadrillage
nbCartes=34 # le nombre de cartes pour le cadrillage
listeCoupsJoues=[] # liste des coups joués pour le bouton "oups"
forme=0 # forme pour les différents types de grilles

#importation des images dans une liste
listeTuiles=[]
for i in range(1,35):
    listeTuiles.append(PhotoImage(file='tuiles/t'+str(i)+".gif"))
    
# Fonctions Tkinter

def monquitter():
    dessin.quit()
    dessin.destroy()

def boutonJouer(n):
    global nbLignes
    global nbColonnes
    global nbCartes
    global grille
    global copieGrille
    global listeCoupsJoues
    global forme
    interfaceJeu()
    # évènement de la souris
    dessin.bind('<Button-1>',cliquer)
    if n==1:
        if forme==0:
            grille=aleaGrille(nbLignes,nbColonnes,nbCartes)
            copieGrille=deepcopy(grille)
        elif forme==1:
            grille=aleaGrilleRectangle(nbLignes,nbColonnes,nbCartes)
            copieGrille=deepcopy(grille)
        elif forme==2:
            grille=aleaGrilleDouble(nbLignes,nbColonnes,nbCartes)
            copieGrille=deepcopy(grille)
        elif forme==3:
            grille=aleaGrilleCroix(nbLignes,nbColonnes,nbCartes)
            copieGrille=deepcopy(grille)
        elif forme==4:
            grille=aleaGrilleLosange(nbLignes,nbColonnes,nbCartes)
            copieGrille=deepcopy(grille)
        elif forme==5:
            grille=aleaGrilleDonut(nbLignes,nbColonnes,nbCartes)
            copieGrille=deepcopy(grille)
    else:
        grille=deepcopy(copieGrille)
    afficheGrille(grille)
    finJeu.delete("0.0",END)
    uneTuile.config(state=ACTIVE)
    coupleTuile.config(state=ACTIVE)
    oups.config(state=ACTIVE)
    nouvelleGrille.config(state=DISABLED)
    rejouerGrille.config(state=DISABLED)
    commentJouer.pack_forget()
    sauvegarder.pack()
    listeCoupsJoues=[]

def changeGrilleForme(i,lignes,colonnes,cartes):
    global forme
    global nbLignes
    global nbColonnes
    global nbCartes
    nbLignes=lignes
    nbColonnes=colonnes
    nbCartes=cartes
    forme=i
    if forme==0:
        ok_1.config(state=ACTIVE)
        ok_2.config(state=ACTIVE)
    else:
        ok_1.config(state=DISABLED)
        ok_2.config(state=DISABLED)

def finDuJeu(grille):
    if estVide(grille)==True:
        dessin.unbind('<Button-1>')
        finJeu.delete("0.0",END)
        finJeu.insert(END,"Bravo vous avez gagné !")
        uneTuile.config(state=DISABLED)
        coupleTuile.config(state=DISABLED)
        oups.config(state=DISABLED)
        nouvelleGrille.config(state=ACTIVE)
        rejouerGrille.config(state=ACTIVE)
    elif bloquee(grille)==True:
        dessin.unbind('<Button-1>')
        finJeu.delete("0.0",END)
        finJeu.insert(END,"Situation bloquée, c'est perdu !")
        uneTuile.config(state=DISABLED)
        coupleTuile.config(state=DISABLED)
        oups.config(state=DISABLED)
        rejouerGrille.config(state=ACTIVE)
        nouvelleGrille.config(state=ACTIVE)
    else:
        return False
    
def affichageNombreTuiles(grille):
    tuilesRestantes.delete("0.0",END)
    cp=0
    for i in range(len(grille)):
        for j in range(len(grille[i])):
            for tuile in grille[i][j]:
                cp+=1
    tuilesRestantes.insert(END,"il reste : "+str(cp)+" tuile(s)")

def proposerTuileJouable():
    global grille
    global cx
    global cy
    global x0, y0
    global click1
    global click2
    click1=()
    click2=()
    afficheGrille(grille)
    tuile=unCoup(grille)
    i=tuile[0][0]
    j=tuile[0][1]
    cadrillage.create_rectangle(x0+cx*j+5, y0+cy*i+5, x0+cx*j+cx-5, y0+cy*i+cy-5,outline='black', width=3)
    uneTuile.config(state=DISABLED)
    coupleTuile.config(state=DISABLED)
    
def proposerCoupleTuileJouable():
    global grille
    global cx
    global cy
    global x0, y0
    global click1
    global click2
    click1=()
    click2=()
    afficheGrille(grille)
    tuile=unCoup(grille)
    i=tuile[0][0]
    j=tuile[0][1]
    k=tuile[1][0]
    m=tuile[1][1]
    cadrillage.create_rectangle(x0+cx*j+5, y0+cy*i+5, x0+cx*j+cx-5, y0+cy*i+cy-5,outline='black', width=3)
    cadrillage.create_rectangle(x0+cx*m+5, y0+cy*k+5, x0+cx*m+cx-5, y0+cy*k+cy-5,outline='black', width=3)
    uneTuile.config(state=DISABLED)
    coupleTuile.config(state=DISABLED)

def coupsDejaJoues():
    global grille
    global listeCoupsJoues
    if listeCoupsJoues!=[]:
        ajoute(grille,listeCoupsJoues[0][0],listeCoupsJoues[0][1][0],listeCoupsJoues[0][1][1])
        ajoute(grille,listeCoupsJoues[0][0],listeCoupsJoues[0][2][0],listeCoupsJoues[0][2][1])
        listeCoupsJoues.pop(0)
        afficheGrille(grille)

def demo():
    global grille
    global nbLignes
    global nbColonnes
    global nbCartes
    global forme
    dessin.unbind('<Button-1>')
    finJeu.delete("0.0",END)
    interfaceJeu()
    if forme==0:
        grille=aleaGrille(nbLignes,nbColonnes,nbCartes)
    elif forme==1:
        grille=aleaGrilleRectangle(nbLignes,nbColonnes,nbCartes)
    elif forme==2:
        grille=aleaGrilleDouble(nbLignes,nbColonnes,nbCartes)
    elif forme==3:
        grille=aleaGrilleCroix(nbLignes,nbColonnes,nbCartes)
    elif forme==4:
        grille=aleaGrilleLosange(nbLignes,nbColonnes,nbCartes)
    elif forme==5:
        grille=aleaGrilleDonut(nbLignes,nbColonnes,nbCartes)
    afficheGrille(grille)
    oups.config(state=DISABLED)
    uneTuile.config(state=DISABLED)
    coupleTuile.config(state=DISABLED)
    sauvegarder.pack_forget()
    commentJouer.pack(side=TOP,pady=30)
    finJeu.insert(END,'Cliquez sur le bouton\n"comment jouer ?"')

def commentJouer():
    global grille
    global cx
    global cy
    global x0, y0
    commentJouer.config(state=DISABLED)
    finJeu.delete("0.0",END)
    finJeu.insert(END,'Vous devrez cliquer sur\nles cartes identiques')
    if couplesTuilesJouables(grille)!=[]:
        tuile=unCoup(grille)
        i=tuile[0][0]
        j=tuile[0][1]
        k=tuile[1][0]
        m=tuile[1][1]
        cadrillage.create_rectangle(x0+cx*j+5, y0+cy*i+5, x0+cx*j+cx-5, y0+cy*i+cy-5,outline='black', width=3)
        cadrillage.create_rectangle(x0+cx*m+5, y0+cy*k+5, x0+cx*m+cx-5, y0+cy*k+cy-5,outline='black', width=3)
        cadrillage.update()
        cadrillage.after(2000)
        retire(grille,tuile[0][0],tuile[0][1])
        retire(grille,tuile[1][0],tuile[1][1])
        afficheGrille(grille)
        commentJouer.config(state=ACTIVE)
    else:
        commentJouer.config(state=DISABLED)

def nombreLignesColonnes():
    global nbLignes
    global nbColonnes
    try:
        l=int(entreLignes.get())
        c=int(entreColonnes.get())
        if l>=4 and l<=8:
            entreLignes.delete("0",END)
            entreColonnes.delete("0",END)
            nbLignes=l
            nbColonnes=c
    except ValueError:
        pass

def nombreCartes():
    global nbCartes
    try:
        c=int(entreCartes.get())
        if c>=10 and c<=34:
            entreCartes.delete("0",END)
            nbCartes=c
    except ValueError:
        pass

def couleurJeu(couleur):
    cadrillage['bg']=couleur
    interface_menu['bg']=couleur
    interface_choix_parametre['bg']=couleur
    titreTaille['bg']=couleur
    taille_frame['bg']=couleur
    titreLignes['bg']=couleur
    titreColonnes['bg']=couleur
    titreNbCartes['bg']=couleur
    nbCartes_frame['bg']=couleur
    titreCartes['bg']=couleur
    titreTypeGrille['bg']=couleur
    interface_choix_couleur['bg']=couleur
    titreCouleurFond['bg']=couleur
    aleaGrille_frame['bg']=couleur

def sauvegarde():
    global grille
    global copieGrille
    global nbLignes
    global nbColonnes
    global nbCartes
    global listeCoupsJoues
    dicoDeSvg={'grille':grille,'copieGrille':copieGrille,'nbLignes':nbLignes,'nbColonnes':nbColonnes,'nbCartes':nbCartes,'listeCoupsJoues':listeCoupsJoues}
    monport=open("sauvegarde/sauvegarde","wb")
    dump(dicoDeSvg,monport)
    monport.close()

def reprendreSauvegarde():
    global grille
    global copieGrille
    global nbLignes
    global nbColonnes
    global nbCartes
    global listeCoupsJoues
    global forme
    try:
        monport=open("sauvegarde/sauvegarde","rb")
        dicoDeSvg=load(monport)
        monport.close()
        grille=dicoDeSvg['grille']
        copieGrille=dicoDeSvg['copieGrille']
        nbLignes=dicoDeSvg['nbLignes']
        nbColonnes=dicoDeSvg['nbColonnes']
        nbCartes=dicoDeSvg['nbCartes']
        listeCoupsJoues=dicoDeSvg['listeCoupsJoues']
        forme=0
        interfaceJeu()
        # évènement de la souris
        dessin.bind('<Button-1>',cliquer)
        afficheGrille(grille)
        finJeu.delete("0.0",END)
        uneTuile.config(state=ACTIVE)
        coupleTuile.config(state=ACTIVE)
        oups.config(state=ACTIVE)
        nouvelleGrille.config(state=DISABLED)
        commentJouer.pack_forget()
        sauvegarder.pack()
    except FileNotFoundError:
        pass

def afficheGrille(grille):
    cadrillage.delete(ALL)
    affichageNombreTuiles(grille)
    for i in range(nbLignes):  
        for j in range(nbColonnes):
            if grille[i][j]!=[]:
                if i%2==0 and j%2==0:
                    cadrillage.create_rectangle(x0+cx*j+5, y0+cy*i+5, x0+cx*j+cx-5, y0+cy*i+cy-5,outline='red',width=3)
                elif i%2==1 and j%2==1:
                    cadrillage.create_rectangle(x0+cx*j+5, y0+cy*i+5, x0+cx*j+cx-5, y0+cy*i+cy-5,outline='blue',width=3)
                else:
                    cadrillage.create_rectangle(x0+cx*j+5, y0+cy*i+5, x0+cx*j+cx-5, y0+cy*i+cy-5,outline='yellow',width=3) 
            listeT=grille[i][j]
            try :
                cadrillage.create_image(x0+cx*j+cx/2+1, y0+cy*i+cy/2,image=listeTuiles[listeT[0]-1])
            except IndexError:
                continue

def cliquer(event):
    global grille
    global cx
    global cy
    global x0, y0
    global click1
    global click2
    global nbLignes
    global nbColonnes
    pos=correspond(event.x,event.y)
    i=pos[0]
    j=pos[1]
    if i in range(nbLignes) and j in range(nbColonnes):
        if click1==() and grille[pos[0]][pos[1]]!=[]:
            click1=pos
            cadrillage.create_rectangle(x0+cx*j+5, y0+cy*i+5, x0+cx*j+cx-5, y0+cy*i+cy-5,outline='navy', width=3)
        else:
            uneTuile.config(state=ACTIVE)
            coupleTuile.config(state=ACTIVE)
            click2=pos
            cadrillage.create_rectangle(x0+cx*j+5, y0+cy*i+5, x0+cx*j+cx-5, y0+cy*i+cy-5,outline='navy', width=3)
            if click1==click2:
                click1=()
                click2=()
                afficheGrille(grille)
            else:
                try:
                    if grille[click1[0]][click1[1]][0]==grille[click2[0]][click2[1]][0]:
                        listeCoupsJoues.insert(0,(grille[click1[0]][click1[1]][0],(click1),(click2)))
                        retire(grille,click1[0],click1[1])
                        retire(grille,click2[0],click2[1])
                        finDuJeu(grille)
                        afficheGrille(grille)
                        click1=()
                        click2=()
                    else:
                        click1=()
                        click2=()
                        afficheGrille(grille)
                except IndexError:
                    click1=()
                    click2=()
                    afficheGrille(grille)

#correspondance entre la position du click et la case de la grille
def correspond(x,y):
    return (y-y0)//cy, (x-x0)//cx

def interfaceMenu():
    interface_jeu.pack_forget()
    interface_choix_parametre.pack_forget()
    interface_choix_couleur.pack_forget()
    interface_menu.pack()

def interfaceJeu():
    interface_menu.pack_forget()
    interface_jeu.pack()

def interfaceChoixParametres():
    interface_menu.pack_forget()
    interface_choix_parametre.pack()

def interfaceChoixCouleurs():
    interface_menu.pack_forget()
    interface_choix_couleur.pack()
    
# Définition des widgets de la partie jeu

#frame (les différentes interfaces)
interface_choix_couleur=Frame(dessin)
interface_choix_couleur.pack_forget()

interface_choix_parametre=Frame(dessin)
interface_choix_parametre.pack_forget()

interface_menu=Frame(dessin)
interface_menu.pack()

interface_jeu=Frame(dessin)
interface_jeu.pack_forget()

################ dans l'interface pour choisir la couleur de fond du jeu ################

#titre de la section "couleur de fond"
titreCouleurFond=Label(interface_choix_couleur,text='Choisissez la couleur du fond de jeu')
titreCouleurFond.config(font=('comic',10,'bold'))
titreCouleurFond.grid(row=0,column=2,columnspan=2,padx=10,pady=20)

#les boutons pour les différents coloris
coloris1=Button(interface_choix_couleur,text="coloris 1",command=lambda:couleurJeu('darkgreen'))
coloris1.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
coloris1.grid(row=1,column=1,pady=10)

coloris2=Button(interface_choix_couleur,text="coloris 2",command=lambda:couleurJeu('limegreen'))
coloris2.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
coloris2.grid(row=2,column=1)

coloris3=Button(interface_choix_couleur,text="coloris 3",command=lambda:couleurJeu('mediumseagreen'))
coloris3.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
coloris3.grid(row=3,column=1,pady=10)

coloris4=Button(interface_choix_couleur,text="coloris 4",command=lambda:couleurJeu('darkolivegreen'))
coloris4.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
coloris4.grid(row=4,column=1)

coloris5=Button(interface_choix_couleur,text="coloris 5",command=lambda:couleurJeu('cadetblue'))
coloris5.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
coloris5.grid(row=1,column=2,pady=10)

coloris6=Button(interface_choix_couleur,text="coloris 6",command=lambda:couleurJeu('darkcyan'))
coloris6.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
coloris6.grid(row=2,column=2)

coloris7=Button(interface_choix_couleur,text="coloris 7",command=lambda:couleurJeu('darkturquoise'))
coloris7.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
coloris7.grid(row=3,column=2,pady=10)

coloris8=Button(interface_choix_couleur,text="coloris 8",command=lambda:couleurJeu('lightblue'))
coloris8.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
coloris8.grid(row=4,column=2)

coloris9=Button(interface_choix_couleur,text="coloris 9",command=lambda:couleurJeu('hotpink'))
coloris9.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
coloris9.grid(row=1,column=3,pady=10,ipadx=3)

coloris10=Button(interface_choix_couleur,text="coloris 10",command=lambda:couleurJeu('mediumorchid'))
coloris10.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
coloris10.grid(row=2,column=3)

coloris11=Button(interface_choix_couleur,text="coloris 11",command=lambda:couleurJeu('mediumpurple'))
coloris11.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
coloris11.grid(row=3,column=3,pady=10)

coloris12=Button(interface_choix_couleur,text="coloris 12",command=lambda:couleurJeu('orchid'))
coloris12.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
coloris12.grid(row=4,column=3)

coloris13=Button(interface_choix_couleur,text="coloris 13",command=lambda:couleurJeu('thistle'))
coloris13.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
coloris13.grid(row=1,column=4)

coloris14=Button(interface_choix_couleur,text="coloris 14",command=lambda:couleurJeu('tan'))
coloris14.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
coloris14.grid(row=2,column=4)

coloris15=Button(interface_choix_couleur,text="coloris 15",command=lambda:couleurJeu('grey'))
coloris15.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
coloris15.grid(row=3,column=4,pady=10)

coloris16=Button(interface_choix_couleur,text="coloris 16",command=lambda:couleurJeu('peru'))
coloris16.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
coloris16.grid(row=4,column=4)

#bouton quitter
quitter=Button(interface_choix_couleur,text="Quitter",command=monquitter)
quitter.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
quitter.grid(row=5,column=0,padx=10,pady=10)

#bouton menu
menu=Button(interface_choix_couleur,text='Menu',command=interfaceMenu)
menu.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
menu.grid(row=5,column=5,padx=10,pady=10)

################ dans l'interface pour choisir la taille de la grille ################

#titre de la section "taille de la grille"
titreTaille=Label(interface_choix_parametre,text='Choisissez la taille de la grille.\nEntre 4 et 8 pour le nombre de lignes et de colonnes.')
titreTaille.config(font=('comic',10,'bold'))
titreTaille.pack(side=TOP,padx=10,pady=20)

#frame qui regroupe les labels,entrées et le bouton au dessous
taille_frame=Frame(interface_choix_parametre)
taille_frame.pack(side=TOP,pady=20,padx=10)

#titre pour indiquer où il faut mettre le nombre de lignes
titreLignes=Label(taille_frame,text='nombre de lignes : ')
titreLignes.config(font=('comic',10,'bold'))
titreLignes.pack(side=LEFT)

#entrée pour saisir le nombre de lignes
entreLignes=Entry(taille_frame)
entreLignes.config(font=('comic',10,'bold'))
entreLignes.pack(side=LEFT)

#titre pour indiquer où il faut mettre le nombre de colonnes
titreColonnes=Label(taille_frame,text='nombre de colonnes : ')
titreColonnes.config(font=('comic',10,'bold'))
titreColonnes.pack(side=LEFT)

#entrée pour saisir le nombre de colonnes
entreColonnes=Entry(taille_frame)
entreColonnes.config(font=('comic',10,'bold'))
entreColonnes.pack(side=LEFT)

#bouton ok_1
ok_1=Button(taille_frame,text="OK",command=nombreLignesColonnes)
ok_1.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
ok_1.pack(side=LEFT,padx=10)

#titre de la section "nombre de cartes"
titreNbCartes=Label(interface_choix_parametre,text='Choisissez le nombre de cartes avec lesquels\nvous voulez jouer. Entre 10 et 34 cartes.')
titreNbCartes.config(font=('comic',10,'bold'))
titreNbCartes.pack(side=TOP,padx=10,pady=20)

#frame qui regroupe l'entrée, le label et le bouton ok au dessous
nbCartes_frame=Frame(interface_choix_parametre)
nbCartes_frame.pack(side=TOP,pady=20,padx=10)

#titre pour indiquer où il faut mettre le nombre de cartes
titreCartes=Label(nbCartes_frame,text='Nombre de cartes : ')
titreCartes.config(font=('comic',10,'bold'))
titreCartes.pack(side=LEFT)

#entrée pour saisir le nombre de cartes
entreCartes=Entry(nbCartes_frame)
entreCartes.config(font=('comic',10,'bold'))
entreCartes.pack(side=LEFT)

#bouton ok_2
ok_2=Button(nbCartes_frame,text="OK",command=nombreCartes)
ok_2.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
ok_2.pack(side=LEFT,padx=10)

#titre de la section "type de grille"
titreTypeGrille=Label(interface_choix_parametre,text="Choisissez le type de grille avec\nlaquelle vous souhaitez jouer.\n(taille et nombre de cartes imposés.)")
titreTypeGrille.config(font=('comic',10,'bold'))
titreTypeGrille.pack(side=TOP,padx=10,pady=10)

#frame qui regroupe les boutons des grilles aléatoires
aleaGrille_frame=Frame(interface_choix_parametre)
aleaGrille_frame.pack(side=TOP,pady=20,padx=10)

#bouton pour la grille forme : rectangle
bRectangle=Button(aleaGrille_frame,text='Rectangle',command=lambda:changeGrilleForme(1,8,8,34))
bRectangle.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
bRectangle.grid(row=0,column=0,padx=10,pady=10)

#bouton pour la grille forme : losange
bLosange=Button(aleaGrille_frame,text='Losange',command=lambda:changeGrilleForme(4,8,7,34))
bLosange.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
bLosange.grid(row=1,column=0,columnspan=2,padx=10,pady=10,ipadx=6)

#bouton pour la grille forme : double
bDoubleRectangle=Button(aleaGrille_frame,text='Double',command=lambda:changeGrilleForme(2,8,8,34))
bDoubleRectangle.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
bDoubleRectangle.grid(row=0,column=1,padx=10,pady=10)

#bouton pour la grille forme : donut
bDoubleEpaisseurRectangle=Button(aleaGrille_frame,text='Donut',command=lambda:changeGrilleForme(5,8,8,34))
bDoubleEpaisseurRectangle.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
bDoubleEpaisseurRectangle.grid(row=1,column=1,columnspan=2,padx=10,pady=10,ipadx=20)

#bouton pour la grille forme : croix
bCroix=Button(aleaGrille_frame,text='Croix',command=lambda:changeGrilleForme(3,8,8,34))
bCroix.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
bCroix.grid(row=0,column=2,padx=10,pady=10,ipadx=20)

#bouton pour la grille forme : format classique
bClassique=Button(aleaGrille_frame,text='Retour au format classique',command=lambda:changeGrilleForme(0,8,8,34))
bClassique.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
bClassique.grid(row=2,column=0,columnspan=3,padx=10,pady=10)

#bouton quitter
quitter=Button(interface_choix_parametre,text="Quitter",command=monquitter)
quitter.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
quitter.pack(side=LEFT,padx=10,pady=10)

#bouton menu
menu=Button(interface_choix_parametre,text='Menu',command=interfaceMenu)
menu.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
menu.pack(side=RIGHT,padx=10,pady=10)

################ dans l'interface du menu ################

#bouton demo
demo=Button(interface_menu,text="Mode démo",command=demo)
demo.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
demo.grid(row=0,column=1,ipadx=13,padx=40,pady=20)

#bouton jouer
jouer=Button(interface_menu,text="Jouer avec\nles paramètres",command=lambda:boutonJouer(1))
jouer.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
jouer.grid(row=1,column=1,padx=40,pady=20)

#reprendre une partie en cours
reprendrePartie=Button(interface_menu,text="Reprendre une\npartie en cours",command=reprendreSauvegarde)
reprendrePartie.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
reprendrePartie.grid(row=2,column=1,padx=40,pady=20)

#bouton pour le choix de la couleur du fond du jeu
choixFormeGrille=Button(interface_menu,text="Choisir la couleur\ndu jeu",command=interfaceChoixCouleurs)
choixFormeGrille.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
choixFormeGrille.grid(row=0,column=2,padx=40,pady=20)

#bouton pour le choix des paramètres
choixBackground=Button(interface_menu,text="Choix\ndes paramètres",command=interfaceChoixParametres)
choixBackground.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
choixBackground.grid(row=1,column=2,padx=40,pady=20)

#bouton quitter
quitter=Button(interface_menu,text="Quitter",command=monquitter)
quitter.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
quitter.grid(row=2,column=2,padx=40,pady=20,ipadx=40)

################ dans l'interface du jeu ################

#canvas de la grille
cadrillage=Canvas(interface_jeu,height=810,width=610,bg='lightgrey')
cadrillage.pack(side=LEFT)

#bouton nouvelle grille
nouvelleGrille=Button(interface_jeu,text="Nouvelle grille",command=lambda:boutonJouer(1),state=DISABLED)
nouvelleGrille.config(font=('comic',10,'bold'))
nouvelleGrille.pack(side=TOP,pady=10)

#bouton rejouer avec la grille
rejouerGrille=Button(interface_jeu,text="Rejouer avec\nla même grille",command=lambda:boutonJouer(0),state=DISABLED)
rejouerGrille.config(font=('comic',10,'bold'))
rejouerGrille.pack(side=TOP,pady=5)

#zone de texte
finJeu=Text(interface_jeu,height=2,width=25,bg='white')
finJeu.pack(side=TOP,padx=10,pady=40)

tuilesRestantes=Text(interface_jeu,height=2,width=25,bg='white')
tuilesRestantes.pack(side=TOP,padx=10,pady=20)

#boutons d'aide
uneTuile=Button(interface_jeu,text='Découvrir une tuile ?',command=proposerTuileJouable)
uneTuile.config(font=('comic',10,'bold'))
uneTuile.pack(side=TOP,pady=20)

coupleTuile=Button(interface_jeu,text='Découvrir un couple ?',command=proposerCoupleTuileJouable)
coupleTuile.config(font=('comic',10,'bold'))
coupleTuile.pack(side=TOP)

oups=Button(interface_jeu,text='Oups !',command=coupsDejaJoues)
oups.config(font=('comic',10,'bold'))
oups.pack(side=TOP,pady=20)

#bouton comment jouer
commentJouer=Button(interface_jeu,text='Comment jouer ?',command=commentJouer)
commentJouer.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
commentJouer.pack_forget()

#bouton sauvegarde
sauvegarder=Button(interface_jeu,text='Sauvegarder',command=sauvegarde)
sauvegarder.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
sauvegarder.pack(side=TOP,pady=30)

#frame qui regroupe le bouton quitter et le bouton menu
regroupe_boutons_quitter_menu=Frame(interface_jeu)
regroupe_boutons_quitter_menu.pack(side=BOTTOM)

#bouton menu
menu=Button(regroupe_boutons_quitter_menu,text="Menu",command=interfaceMenu)
menu.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
menu.pack(side=RIGHT,pady=20,padx=10)

#bouton quitter
quitter=Button(regroupe_boutons_quitter_menu,text="Quitter",command=monquitter)
quitter.config(font=('comic',10,'bold'),fg='black',bg='white',activebackground='black',activeforeground='white')
quitter.pack(side=LEFT,pady=20,padx=10)

#################### Démarrage du jeu ####################
dessin.mainloop()

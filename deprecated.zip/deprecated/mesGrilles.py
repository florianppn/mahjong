############################################################################
#  DM MAHJONG Solitaire                                                    #
############################################################################

#importation des bibliothèques nécessaires au jeu
from random import *

def retire(grille,i,j):
    grille[i][j].pop(0)

def ajoute(grille,newtuile,i,j):
    grille[i][j].insert(0,newtuile)
    
def estVide(grille):
    cp=0
    for ligne in range(len(grille)):
        for colonne in range(len(grille[ligne])):
            vide=len(grille[ligne][colonne])
            if vide==0:
                cp+=1
    if cp==len(grille)*len(grille[0]):
        return True
    return False

def listesTuiles(grille):
    liste=[]
    for i in range(len(grille)):
        for j in range(len(grille[i])):
            try:
                liste.append((grille[i][j][0],i,j))
            except IndexError:
                continue
    return liste

def couplesTuilesJouables(grille):
    listeTuilesCoordonnees=listesTuiles(grille)
    listePairesCoordonnees=[]
    Tuple=[]
    for i in range(len(listeTuilesCoordonnees)):
        Tuple.append(listeTuilesCoordonnees[i])
        for i in range(len(listeTuilesCoordonnees)):
            if Tuple[0][0]==listeTuilesCoordonnees[i][0]:
                if Tuple[0]!=listeTuilesCoordonnees[i]:
                    if [(listeTuilesCoordonnees[i][1],listeTuilesCoordonnees[i][2]),(Tuple[0][1],Tuple[0][2])] in listePairesCoordonnees:
                        continue
                    else:
                        listePairesCoordonnees.append([(Tuple[0][1],Tuple[0][2]),(listeTuilesCoordonnees[i][1],listeTuilesCoordonnees[i][2])])
                    
        Tuple=[]
    return listePairesCoordonnees

def bloquee(grille):
    liste=couplesTuilesJouables(grille)
    for i in range(len(liste)):
        if len(liste[i])>1:
            return False #pas bloquee
    return True #bloquee

def unCoup(grille):
    coup=choice(couplesTuilesJouables(grille))
    return coup

def aleaGrille(nbLignes,nbColonnes,nbTuiles):
    listeTuiles=[]
    cp=0
    grille=[]
    for tuile in range(nbTuiles):
        listeTuiles+=[tuile]
    for ligne in range(nbLignes):
        grille+=[[]]
        for colonne in range(nbColonnes):
            grille[ligne]+=[[]]
    while cp<len(listeTuiles):
        for i in range(4):
            i=randint(0,nbLignes-1)
            j=randint(0,nbColonnes-1)
            while grille[i][j]==[cp,cp]:
                i=randint(0,nbLignes-1)
                j=randint(0,nbColonnes-1)
            grille[i][j].append(listeTuiles[cp])
        cp+=1
    return grille

def aleaGrilleRectangle(nbLignes,nbColonnes,nbTuiles):
    dicoTuiles={}
    grille=[]
    for tuile in range(nbTuiles):
        dicoTuiles[tuile]=0
    for ligne in range(nbLignes):
        grille+=[[]]
        for colonne in range(nbColonnes):
            grille[ligne]+=[[]]
    while list(dicoTuiles.values())!=[4]*(nbTuiles):
        for ligne in range(len(grille)):
            for colonne in range(len(grille[ligne])):
                if ligne==0 or ligne==len(grille)-1:
                    carte=choice(list(dicoTuiles.keys()))
                    if dicoTuiles[carte]!=4:
                        if len(grille[ligne][colonne])==len(set(grille[ligne][colonne])):
                            dicoTuiles[carte]+=1
                            grille[ligne][colonne].append(carte)
                elif colonne==0 or colonne==len(grille[ligne])-1:
                    carte=choice(list(dicoTuiles.keys()))
                    if dicoTuiles[carte]!=4:
                        if len(grille[ligne][colonne])==len(set(grille[ligne][colonne])):
                            dicoTuiles[carte]+=1
                            grille[ligne][colonne].append(carte)
    return grille

def aleaGrilleDouble(nbLignes,nbColonnes,nbTuiles):
    dicoTuiles={}
    grille=[]
    for tuile in range(nbTuiles):
        dicoTuiles[tuile]=0
    for ligne in range(nbLignes):
        grille+=[[]]
        for colonne in range(nbColonnes):
            grille[ligne]+=[[]]
    while list(dicoTuiles.values())!=[4]*(nbTuiles):
        for ligne in range(len(grille)):
            for colonne in range(len(grille[ligne])):
                if ligne==0 or ligne==len(grille)-1:
                    carte=choice(list(dicoTuiles.keys()))
                    if dicoTuiles[carte]!=4:
                        if len(grille[ligne][colonne])==len(set(grille[ligne][colonne])):
                            dicoTuiles[carte]+=1
                            grille[ligne][colonne].append(carte)
                elif colonne==0 or colonne==len(grille[ligne])-1:
                    carte=choice(list(dicoTuiles.keys()))
                    if dicoTuiles[carte]!=4:
                        if len(grille[ligne][colonne])==len(set(grille[ligne][colonne])):
                            dicoTuiles[carte]+=1
                            grille[ligne][colonne].append(carte)
                elif ligne==2 or ligne==len(grille)-3:
                    if colonne>1 and colonne<len(grille)-2:
                        carte=choice(list(dicoTuiles.keys()))
                        if dicoTuiles[carte]!=4:
                            if len(grille[ligne][colonne])==len(set(grille[ligne][colonne])):
                                dicoTuiles[carte]+=1
                                grille[ligne][colonne].append(carte)
                elif colonne==2 or colonne==len(grille[ligne])-3:
                    if ligne>1 and ligne<len(grille[ligne])-2:
                        carte=choice(list(dicoTuiles.keys()))
                        if dicoTuiles[carte]!=4:
                            if len(grille[ligne][colonne])==len(set(grille[ligne][colonne])):
                                dicoTuiles[carte]+=1
                                grille[ligne][colonne].append(carte)
                            
    return grille

def aleaGrilleCroix(nbLignes,nbColonnes,nbTuiles):
    dicoTuiles={}
    grille=[]
    for tuile in range(nbTuiles):
        dicoTuiles[tuile]=0
    for ligne in range(nbLignes):
        grille+=[[]]
        for colonne in range(nbColonnes):
            grille[ligne]+=[[]]
    while list(dicoTuiles.values())!=[4]*(nbTuiles):
        for ligne in range(len(grille)):
            for colonne in range(len(grille[ligne])):
                if ligne<len(grille)-5 or ligne>len(grille)-4:
                    if colonne==len(grille[ligne])-5 or colonne==len(grille[ligne])-4:
                        carte=choice(list(dicoTuiles.keys()))
                        if dicoTuiles[carte]!=4:
                            if len(grille[ligne][colonne])==len(set(grille[ligne][colonne])):
                                dicoTuiles[carte]+=1
                                grille[ligne][colonne].append(carte)
                elif ligne==len(grille)-5 or ligne==len(grille)-4:
                    carte=choice(list(dicoTuiles.keys()))
                    if dicoTuiles[carte]!=4:
                        if len(grille[ligne][colonne])==len(set(grille[ligne][colonne])):
                            dicoTuiles[carte]+=1
                            grille[ligne][colonne].append(carte)
    return grille

def aleaGrilleLosange(nbLignes,nbColonnes,nbTuiles):
    dicoTuiles={}
    grille=[]
    for tuile in range(nbTuiles):
        dicoTuiles[tuile]=0
    for ligne in range(nbLignes):
        grille+=[[]]
        for colonne in range(nbColonnes):
            grille[ligne]+=[[]]
    milieu=int((len(grille[ligne])/2))
    while list(dicoTuiles.values())!=[4]*(nbTuiles):
        for ligne in range(len(grille)):
            for colonne in range(len(grille[ligne])):
                if ligne<=milieu:
                    if colonne>=milieu and colonne<=milieu+ligne:
                        carte=choice(list(dicoTuiles.keys()))
                        if dicoTuiles[carte]!=4:
                            if len(grille[ligne][colonne])==len(set(grille[ligne][colonne])):
                                dicoTuiles[carte]+=1
                                grille[ligne][colonne].append(carte)
                    elif colonne<=milieu and colonne>=milieu-ligne:
                        carte=choice(list(dicoTuiles.keys()))
                        if dicoTuiles[carte]!=4:
                            if len(grille[ligne][colonne])==len(set(grille[ligne][colonne])):
                                dicoTuiles[carte]+=1
                                grille[ligne][colonne].append(carte)
                elif ligne>milieu:
                    if colonne>=milieu and colonne<=milieu+(len(grille[ligne])-ligne):
                        carte=choice(list(dicoTuiles.keys()))
                        if dicoTuiles[carte]!=4:
                            if len(grille[ligne][colonne])==len(set(grille[ligne][colonne])):
                                dicoTuiles[carte]+=1
                                grille[ligne][colonne].append(carte)
                    elif colonne<=milieu and colonne>=milieu-(len(grille[ligne])-ligne):
                        carte=choice(list(dicoTuiles.keys()))
                        if dicoTuiles[carte]!=4:
                            if len(grille[ligne][colonne])==len(set(grille[ligne][colonne])):
                                dicoTuiles[carte]+=1
                                grille[ligne][colonne].append(carte)
    return grille
                 

def aleaGrilleDonut(nbLignes,nbColonnes,nbTuiles):
    dicoTuiles={}
    grille=[]
    for tuile in range(nbTuiles):
        dicoTuiles[tuile]=0
    for ligne in range(nbLignes):
        grille+=[[]]
        for colonne in range(nbColonnes):
            grille[ligne]+=[[]]
    while list(dicoTuiles.values())!=[4]*(nbTuiles):
        for ligne in range(len(grille)):
            for colonne in range(len(grille[ligne])):
                if ligne==0 or ligne==len(grille)-1:
                    carte=choice(list(dicoTuiles.keys()))
                    if dicoTuiles[carte]!=4:
                        if len(grille[ligne][colonne])==len(set(grille[ligne][colonne])):
                            dicoTuiles[carte]+=1
                            grille[ligne][colonne].append(carte)
                elif colonne==0 or colonne==len(grille[ligne])-1:
                    carte=choice(list(dicoTuiles.keys()))
                    if dicoTuiles[carte]!=4:
                        if len(grille[ligne][colonne])==len(set(grille[ligne][colonne])):
                            dicoTuiles[carte]+=1
                            grille[ligne][colonne].append(carte)
                elif ligne==1 or ligne==len(grille)-2:
                    if colonne>0 and colonne<len(grille)-1:
                        carte=choice(list(dicoTuiles.keys()))
                        if dicoTuiles[carte]!=4:
                            if len(grille[ligne][colonne])==len(set(grille[ligne][colonne])):
                                dicoTuiles[carte]+=1
                                grille[ligne][colonne].append(carte)
                elif colonne==1 or colonne==len(grille[ligne])-2:
                    if ligne>0 and ligne<len(grille[ligne])-1:
                        carte=choice(list(dicoTuiles.keys()))
                        if dicoTuiles[carte]!=4:
                            if len(grille[ligne][colonne])==len(set(grille[ligne][colonne])):
                                dicoTuiles[carte]+=1
                                grille[ligne][colonne].append(carte)
                            
    return grille

